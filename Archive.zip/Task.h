#ifndef TASK_H
#define TASK_H

#include <string>
#include <vector>
#include <iostream>

using namespace std;

class Task {
private:
    string taskName;
    string description;
    string startDate;
    string endDate;
    string status;
    string assignedTo; // Name of the team member assigned to the task
    string assignedVendor; // Name of the vendor assigned to the task
    vector<Task> subTasks;

public:
    // Default constructor
    Task() = default;

    // Parameterized constructor
    Task(const string& name, const string& desc, const string& start, const string& end, const string& stat, const string& assigned = "Unassigned", const string& vendor = "Unassigned") {
        taskName = name;
        description = desc;
        startDate = start;
        endDate = end;
        status = stat;
        assignedTo = assigned;
        assignedVendor = vendor;
    }



    // Method to assign a team member
    void assignTeamMember(const string& memberName) {
        assignedTo = memberName;
    }

    // Method to assign a vendor
    void assignVendor(const string& vendorName) {
        assignedVendor = vendorName;
    }

    // Method to update just the status
    void updateStatus(const string& newStatus) {
        status = newStatus;
    }

    // Method to add a sub-task
    void addSubTask(const Task& subTask) {
        subTasks.push_back(subTask);
    }

    // Method to display task details, including sub-tasks
    void display(const string& prefix = "") const {
        cout << prefix << "Task Name: " << taskName << endl;
        cout << prefix << "Description: " << description << endl;
        cout << prefix << "Start Date: " << startDate << endl;
        cout << prefix << "End Date: " << endDate << endl;
        cout << prefix << "Status: " << status << endl;
        cout << prefix << "Assigned To: " << assignedTo << endl;
        cout << prefix << "Assigned Vendor: " << assignedVendor << endl;

        if (!subTasks.empty()) {
            cout << prefix << "Sub-tasks:" << endl;
            for (const auto& subTask : subTasks) {
                subTask.display(prefix + "  ");
            }
        }
    }

    // Getters
    string getTaskName() const { return taskName; }
    string getDescription() const { return description; }
    string getStartDate() const { return startDate; }
    string getEndDate() const { return endDate; }
    string getStatus() const { return status; }
    string getAssignedTo() const { return assignedTo; }
    string getAssignedVendor() const { return assignedVendor; }

    // Setters
    void setTaskName(const string& name) { taskName = name; }
    void setDescription(const string& desc) { description = desc; }
    void setStartDate(const string& start) { startDate = start; }
    void setEndDate(const string& end) { endDate = end; }
    const vector<Task>& getSubTasks() const { return subTasks; }
    vector<Task>& getSubTasks_nonconst() { return subTasks; } // Non-const version for modification
};

#endif // TASK_H
