#ifndef CLIENT_H
#define CLIENT_H

#include "Person.h"

class Client : public Person {
private:
    string industryType;

public:
    // Default constructor
    Client() = default;

    // Parameterized constructor
    Client(const string& name, const string& type, const string& contact)
        : Person(name, contact) {
        industryType = type;
    }



    // Overridden method to display client details
    void display() const override {
        cout << "Company Name: " << getName() << endl;
        cout << "Industry Type: " << industryType << endl;
        cout << "Contact Person: " << getContactInfo() << endl;
    }

    // Getter for industry type
    string getIndustryType() const {
        return industryType;
    }

    void setIndustryType(const string& newType) {
        industryType = newType;
    }
};

#endif // CLIENT_H
