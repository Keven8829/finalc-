#include "ProjectManagementSystem.h"
#include "Project.h"
#include <iostream>
#include <string>
#include <limits>
#include <iomanip> 

using namespace std;


void displayMenu() {
    // Using <iomanip> for formatted console output. Source: C++ Reference on std::setw and std::left
    cout << setw(40) << "=========================================================================" << endl;
    cout << "                      Project Management System Menu           " << endl;
    cout << setw(40) << "=========================================================================" << endl;
    cout << left;

    // Projects, Tasks, and People Section
    cout << "  --- Projects & Tasks ---" << setw(28) << "" << "--- People ---" << endl;
    cout << "  " << setw(40) << "1. Add Project" << "11. Add Team Member" << endl;
    cout << "  " << setw(40) << "2. Update Project" << "12. Update Team Member" << endl;
    cout << "  " << setw(40) << "3. Delete Project" << "13. Delete Team Member" << endl;
    cout << "  " << setw(40) << "4. Display Project Details" << "14. Display Team Member Details" << endl;
    cout << "  " << setw(40) << "5. Add Task" << "15. Add Vendor" << endl;
    cout << "  " << setw(40) << "6. Update Task Details" << "16. Update Vendor" << endl;
    cout << "  " << setw(40) << "7. Update Task Status" << "17. Delete Vendor" << endl;
    cout << "  " << setw(40) << "8. Delete Task" << "18. Add Client" << endl;
    cout << "  " << setw(40) << "9. Display Task Details" << "19. Update Client" << endl;
    cout << "  " << setw(40) << "10. Add Sub-task to Task" << "20. Delete Client" << endl;
    cout << endl;

    // Assignments and Reports Section
    cout << "  --- Assignments ---" << setw(32) << "" << "--- System & Reports ---" << endl;
    cout << "  " << setw(40) << "21. Assign Task to Project" << "27. Display Summary of All Entities" << endl;
    cout << "  " << setw(40) << "22. Assign Team Member to Project" << "28. Find Person & Show Project Involvement" << endl;
    cout << "  " << setw(40) << "23. Assign Vendor to Project" << "29. Generate Project Report" << endl;
    cout << "  " << setw(40) << "24. Assign Client to Project" << "30. Show Project Count" << endl;
    cout << "  " << setw(40) << "25. Assign Task to Team Member" << endl;
    cout << "  " << setw(40) << "26. Assign Vendor to Task" << endl;
    cout << endl;

    // Exit
    cout << "  " << setw(40) << "0. Save and Exit" << endl;
    cout << "========================================================================" << endl;
    cout << "Enter your choice: ";
}

void getLine(string& str) {
    getline(cin, str);
}

void displayUpdateProjectMenu() {
    cout << "\n--- Update Project ---" << endl;
    cout << "1. Update Name" << endl;
    cout << "2. Update Description" << endl;
    cout << "3. Update Start Date" << endl;
    cout << "4. Update End Date" << endl;
    cout << "5. Update Status" << endl;
    cout << "0. Back to Main Menu" << endl;
    cout << "Enter your choice: ";
}

void displayUpdateTaskMenu() {
    cout << "\n--- Update Task ---" << endl;
    cout << "1. Update Name" << endl;
    cout << "2. Update Description" << endl;
    cout << "3. Update Start Date" << endl;
    cout << "4. Update End Date" << endl;
    cout << "0. Back to Main Menu" << endl;
    cout << "Enter your choice: ";
}

void displayUpdateTeamMemberMenu() {
    cout << "\n--- Update Team Member ---" << endl;
    cout << "1. Update Name" << endl;
    cout << "2. Update Role" << endl;
    cout << "3. Update Contact Info" << endl;
    cout << "0. Back to Main Menu" << endl;
    cout << "Enter your choice: ";
}

void displayUpdateVendorMenu() {
    cout << "\n--- Update Vendor ---" << endl;
    cout << "1. Update Name" << endl;
    cout << "2. Update Service Type" << endl;
    cout << "3. Update Contact Info" << endl;
    cout << "0. Back to Main Menu" << endl;
    cout << "Enter your choice: ";
}

void displayUpdateClientMenu() {
    cout << "\n--- Update Client ---" << endl;
    cout << "1. Update Name" << endl;
    cout << "2. Update Industry" << endl;
    cout << "3. Update Contact Info" << endl;
    cout << "0. Back to Main Menu" << endl;
    cout << "Enter your choice: ";
}

string selectStatus() {
    cout << "\n--- Select Status ---" << endl;
    cout << "1. Not started" << endl;
    cout << "2. In Progress" << endl;
    cout << "3. Completed" << endl;
    cout << "4. Incomplete" << endl;
    cout << "5. Canceled" << endl;
    cout << "Enter your choice: ";
    int choice;
    cin >> choice;
    // Input validation using std::numeric_limits to clear buffer. Source: Stack Overflow - 'How to clear cin buffer'
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    switch (choice) {
        case 1: return "Not started";
        case 2: return "In Progress";
        case 3: return "Completed";
        case 4: return "Incomplete";
        case 5: return "Canceled";
        default: return ""; // Invalid choice
    }
}

template<typename T, typename F>
int selectEntity(const vector<T>& entities, const string& prompt, F getName) {
    if (entities.empty()) {
        cout << "No entities available." << endl;
        return -1;
    }
    cout << prompt << endl;
    for (size_t i = 0; i < entities.size(); ++i) {
        cout << i + 1 << ". " << getName(entities[i]) << endl;
    }
    int choice;
    cout << "Enter your choice (0 to cancel): ";
    cin >> choice;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    if (choice > 0 && choice <= entities.size()) {
        return choice - 1;
    }
    return -1; // Invalid or canceled
}

int main() {
    ProjectManagementSystem pms;
    pms.loadAllData();
    int choice;

    do {
        displayMenu();
        cin >> choice;

        // Clear the input buffer to prevent issues with getline
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        string name, desc, start, end, stat, role, contact, type;
        string oldName, newName, newDesc, newStart, newEnd, newStat, newRole, newContact, newType;
        string name2;

        switch (choice) {
            // --- Project Cases ---
            case 1: // Add Project
                cout << "Enter Project Name: "; getLine(name);
                cout << "Enter Description: "; getLine(desc);
                cout << "Enter Start Date: "; getLine(start);
                cout << "Enter End Date: "; getLine(end);
                stat = selectStatus();
                if (!stat.empty()) {
                    pms.addProject(name, desc, start, end, stat);
                } else {
                    cout << "Invalid status choice." << endl;
                }
                break;
            case 2: { // Update Project
                int idx = selectEntity(pms.getProjects(), "Select a Project to Update:", [](const Project& p){ return p.getProjectName(); });
                if (idx != -1) {
                    Project* projectToUpdate = pms.findProject(pms.getProjects()[idx].getProjectName());
                    int updateChoice;
                    do {
                        displayUpdateProjectMenu();
                        cin >> updateChoice;
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        string newValue;
                        switch (updateChoice) {
                            case 1: cout << "Enter New Project Name: "; getLine(newValue); projectToUpdate->setProjectName(newValue); break;
                            case 2: cout << "Enter New Description: "; getLine(newValue); projectToUpdate->setDescription(newValue); break;
                            case 3: cout << "Enter New Start Date: "; getLine(newValue); projectToUpdate->setStartDate(newValue); break;
                            case 4: cout << "Enter New End Date: "; getLine(newValue); projectToUpdate->setEndDate(newValue); break;
                            case 5: {
                                newValue = selectStatus();
                                if (!newValue.empty()) {
                                    projectToUpdate->setStatus(newValue);
                                } else {
                                    cout << "Invalid status choice." << endl;
                                }
                                break;
                            }
                        }
                        if(updateChoice >= 1 && updateChoice <= 5) cout << "Project updated successfully." << endl;
                    } while (updateChoice != 0);
                }
                break;
            }
            case 3: { // Delete Project
                int idx = selectEntity(pms.getProjects(), "Select a Project to Delete:", [](const Project& p){ return p.getProjectName(); });
                if (idx != -1) pms.deleteProject(pms.getProjects()[idx].getProjectName());
                break;
            }
            case 4: { // Display Project Details
                int idx = selectEntity(pms.getProjects(), "Select a Project to Display:", [](const Project& p){ return p.getProjectName(); });
                if (idx != -1) pms.displayProjectDetails(pms.getProjects()[idx].getProjectName());
                break;
            }

            // --- Task Cases ---
            case 5: // Add Task
                cout << "Enter Task Name: "; getLine(name);
                cout << "Enter Description: "; getLine(desc);
                cout << "Enter Start Date: "; getLine(start);
                cout << "Enter End Date: "; getLine(end);
                stat = selectStatus();
                if (!stat.empty()) {
                    pms.addTask(name, desc, start, end, stat);
                } else {
                    cout << "Invalid status choice." << endl;
                }
                break;
            case 6: { // Update Task Details
                int idx = selectEntity(pms.getTasks(), "Select a Task to Update:", [](const Task& t){ return t.getTaskName(); });
                if (idx != -1) {
                    Task* taskToUpdate = pms.findTask(pms.getTasks()[idx].getTaskName());
                    int updateChoice;
                    do {
                        displayUpdateTaskMenu();
                        cin >> updateChoice;
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        string newValue;
                        switch (updateChoice) {
                            case 1: cout << "Enter New Task Name: "; getLine(newValue); taskToUpdate->setTaskName(newValue); break;
                            case 2: cout << "Enter New Description: "; getLine(newValue); taskToUpdate->setDescription(newValue); break;
                            case 3: cout << "Enter New Start Date: "; getLine(newValue); taskToUpdate->setStartDate(newValue); break;
                            case 4: cout << "Enter New End Date: "; getLine(newValue); taskToUpdate->setEndDate(newValue); break;
                        }
                        if(updateChoice >= 1 && updateChoice <= 4) cout << "Task updated successfully." << endl;
                    } while (updateChoice != 0);
                }
                break;
            }
            case 7: { // Update Task Status
                int idx = selectEntity(pms.getTasks(), "Select a Task to Update Status:", [](const Task& t){ return t.getTaskName(); });
                if (idx != -1) {
                    newStat = selectStatus();
                    if (!newStat.empty()) {
                        pms.updateTaskStatus(pms.getTasks()[idx].getTaskName(), newStat);
                    } else {
                        cout << "Invalid status choice." << endl;
                    }
                }
                break;
            }
            case 8: { // Delete Task
                int idx = selectEntity(pms.getTasks(), "Select a Task to Delete:", [](const Task& t){ return t.getTaskName(); });
                if (idx != -1) pms.deleteTask(pms.getTasks()[idx].getTaskName());
                break;
            }
            case 9: { // Display Task Details
                int idx = selectEntity(pms.getTasks(), "Select a Task to Display:", [](const Task& t){ return t.getTaskName(); });
                if (idx != -1) pms.displayTaskDetails(pms.getTasks()[idx].getTaskName());
                break;
            }
            case 10: { // Add Sub-task to Task
                int idx = selectEntity(pms.getTasks(), "Select a Parent Task:", [](const Task& t){ return t.getTaskName(); });
                if (idx != -1) {
                    cout << "Enter Sub-task Name: "; getLine(newName);
                    cout << "Enter Sub-task Description: "; getLine(newDesc);
                    cout << "Enter Sub-task Start Date: "; getLine(newStart);
                    cout << "Enter Sub-task End Date: "; getLine(newEnd);
                    newStat = selectStatus();
                    if (!newStat.empty()) {
                        pms.addSubTaskToTask(pms.getTasks()[idx].getTaskName(), Task(newName, newDesc, newStart, newEnd, newStat));
                    } else {
                        cout << "Invalid status choice." << endl;
                    }
                }
                break;
            }

            // --- Team Member Cases ---
            case 11: // Add Team Member
                cout << "Enter Team Member Name: "; getLine(name);
                cout << "Enter Role: "; getLine(role);
                cout << "Enter Contact Info: "; getLine(contact);
                pms.addTeamMember(name, role, contact);
                break;
            case 12: { // Update Team Member
                int idx = selectEntity(pms.getTeamMembers(), "Select a Team Member to Update:", [](const TeamMember& tm){ return tm.getName(); });
                if (idx != -1) {
                    TeamMember* memberToUpdate = pms.findTeamMember(pms.getTeamMembers()[idx].getName());
                    int updateChoice;
                    do {
                        displayUpdateTeamMemberMenu();
                        cin >> updateChoice;
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        string newValue;
                        switch (updateChoice) {
                            case 1: cout << "Enter New Name: "; getLine(newValue); memberToUpdate->setName(newValue); break;
                            case 2: cout << "Enter New Role: "; getLine(newValue); memberToUpdate->setRole(newValue); break;
                            case 3: cout << "Enter New Contact Info: "; getLine(newValue); memberToUpdate->setContactInfo(newValue); break;
                        }
                        if(updateChoice >= 1 && updateChoice <= 3) cout << "Team Member updated successfully." << endl;
                    } while (updateChoice != 0);
                }
                break;
            }
            case 13: { // Delete Team Member
                int idx = selectEntity(pms.getTeamMembers(), "Select a Team Member to Delete:", [](const TeamMember& tm){ return tm.getName(); });
                if (idx != -1) pms.deleteTeamMember(pms.getTeamMembers()[idx].getName());
                break;
            }
            case 14: { // Display Team Member Details
                int idx = selectEntity(pms.getTeamMembers(), "Select a Team Member to Display:", [](const TeamMember& tm){ return tm.getName(); });
                if (idx != -1) pms.displayTeamMemberDetails(pms.getTeamMembers()[idx].getName());
                break;
            }

            // --- Vendor Cases ---
            case 15: // Add Vendor
                cout << "Enter Vendor Name: "; getLine(name);
                cout << "Enter Service Type: "; getLine(type);
                cout << "Enter Contact Info: "; getLine(contact);
                pms.addVendor(name, type, contact);
                break;
            case 16: { // Update Vendor
                int idx = selectEntity(pms.getVendors(), "Select a Vendor to Update:", [](const Vendor& v){ return v.getName(); });
                if (idx != -1) {
                    Vendor* vendorToUpdate = pms.findVendor(pms.getVendors()[idx].getName());
                    int updateChoice;
                    do {
                        displayUpdateVendorMenu();
                        cin >> updateChoice;
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        string newValue;
                        switch (updateChoice) {
                            case 1: cout << "Enter New Name: "; getLine(newValue); vendorToUpdate->setName(newValue); break;
                            case 2: cout << "Enter New Service Type: "; getLine(newValue); vendorToUpdate->setCompanyType(newValue); break;
                            case 3: cout << "Enter New Contact Info: "; getLine(newValue); vendorToUpdate->setContactInfo(newValue); break;
                        }
                        if(updateChoice >= 1 && updateChoice <= 3) cout << "Vendor updated successfully." << endl;
                    } while (updateChoice != 0);
                }
                break;
            }
            case 17: { // Delete Vendor
                int idx = selectEntity(pms.getVendors(), "Select a Vendor to Delete:", [](const Vendor& v){ return v.getName(); });
                if (idx != -1) pms.deleteVendor(pms.getVendors()[idx].getName());
                break;
            }

            // --- Client Cases ---
            case 18: // Add Client
                cout << "Enter Client Name: "; getLine(name);
                cout << "Enter Industry: "; getLine(type);
                cout << "Enter Contact Info: "; getLine(contact);
                pms.addClient(name, type, contact);
                break;
            case 19: { // Update Client
                int idx = selectEntity(pms.getClients(), "Select a Client to Update:", [](const Client& c){ return c.getName(); });
                if (idx != -1) {
                    Client* clientToUpdate = pms.findClient(pms.getClients()[idx].getName());
                    int updateChoice;
                    do {
                        displayUpdateClientMenu();
                        cin >> updateChoice;
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        string newValue;
                        switch (updateChoice) {
                            case 1: cout << "Enter New Name: "; getLine(newValue); clientToUpdate->setName(newValue); break;
                            case 2: cout << "Enter New Industry: "; getLine(newValue); clientToUpdate->setIndustryType(newValue); break;
                            case 3: cout << "Enter New Contact Info: "; getLine(newValue); clientToUpdate->setContactInfo(newValue); break;
                        }
                        if(updateChoice >= 1 && updateChoice <= 3) cout << "Client updated successfully." << endl;
                    } while (updateChoice != 0);
                }
                break;
            }
            case 20: { // Delete Client
                int idx = selectEntity(pms.getClients(), "Select a Client to Delete:", [](const Client& c){ return c.getName(); });
                if (idx != -1) pms.deleteClient(pms.getClients()[idx].getName());
                break;
            }

            // --- Assignment Cases ---
            case 21: { // Assign Task to Project
                int projIdx = selectEntity(pms.getProjects(), "Select a Project:", [](const Project& p){ return p.getProjectName(); });
                if (projIdx != -1) {
                    int taskIdx = selectEntity(pms.getTasks(), "Select a Task to Assign:", [](const Task& t){ return t.getTaskName(); });
                    if (taskIdx != -1) {
                        pms.assignTaskToProject(pms.getProjects()[projIdx].getProjectName(), pms.getTasks()[taskIdx].getTaskName());
                    }
                }
                break;
            }
            case 22: { // Assign Team Member to Project
                int projIdx = selectEntity(pms.getProjects(), "Select a Project:", [](const Project& p){ return p.getProjectName(); });
                if (projIdx != -1) {
                    int memberIdx = selectEntity(pms.getTeamMembers(), "Select a Team Member to Assign:", [](const TeamMember& tm){ return tm.getName(); });
                    if (memberIdx != -1) {
                        pms.assignTeamMemberToProject(pms.getProjects()[projIdx].getProjectName(), pms.getTeamMembers()[memberIdx].getName());
                    }
                }
                break;
            }
            case 23: { // Assign Vendor to Project
                int projIdx = selectEntity(pms.getProjects(), "Select a Project:", [](const Project& p){ return p.getProjectName(); });
                if (projIdx != -1) {
                    int vendorIdx = selectEntity(pms.getVendors(), "Select a Vendor to Assign:", [](const Vendor& v){ return v.getName(); });
                    if (vendorIdx != -1) {
                        pms.assignVendorToProject(pms.getProjects()[projIdx].getProjectName(), pms.getVendors()[vendorIdx].getName());
                    }
                }
                break;
            }
            case 24: { // Assign Client to Project
                int projIdx = selectEntity(pms.getProjects(), "Select a Project:", [](const Project& p){ return p.getProjectName(); });
                if (projIdx != -1) {
                    int clientIdx = selectEntity(pms.getClients(), "Select a Client to Assign:", [](const Client& c){ return c.getName(); });
                    if (clientIdx != -1) {
                        pms.assignClientToProject(pms.getProjects()[projIdx].getProjectName(), pms.getClients()[clientIdx].getName());
                    }
                }
                break;
            }
            case 25: { // Assign Task to Team Member
                int taskIdx = selectEntity(pms.getTasks(), "Select a Task:", [](const Task& t){ return t.getTaskName(); });
                if (taskIdx != -1) {
                    int memberIdx = selectEntity(pms.getTeamMembers(), "Select a Team Member to Assign:", [](const TeamMember& tm){ return tm.getName(); });
                    if (memberIdx != -1) {
                        pms.assignTaskToTeamMember(pms.getTasks()[taskIdx].getTaskName(), pms.getTeamMembers()[memberIdx].getName());
                    }
                }
                break;
            }
            case 26: { // Assign Vendor to Task
                int taskIdx = selectEntity(pms.getTasks(), "Select a Task:", [](const Task& t){ return t.getTaskName(); });
                if (taskIdx != -1) {
                    int vendorIdx = selectEntity(pms.getVendors(), "Select a Vendor to Assign:", [](const Vendor& v){ return v.getName(); });
                    if (vendorIdx != -1) {
                        pms.assignVendorToTask(pms.getTasks()[taskIdx].getTaskName(), pms.getVendors()[vendorIdx].getName());
                    }
                }
                break;
            }

            // --- System & Reports ---
            case 27: // Display Summary of All Entities
                cout << "\n--- System Summary ---" << endl;
                cout << "Total Projects Created: " << Project::getProjectCount() << endl;
                pms.displayAllDetails();
                break;
            case 28: { // Find Person & Show Project Involvement
                vector<Person*> allPeople;
                for(auto& tm : pms.getTeamMembers_nonconst()) allPeople.push_back(&tm);
                for(auto& v : pms.getVendors_nonconst()) allPeople.push_back(&v);
                int idx = selectEntity(allPeople, "Select a Person:", [](const Person* p){ return p->getName(); });
                if(idx != -1) {
                    pms.findPersonAndShowProjects(allPeople[idx]->getName());
                }
                break;
            }
            case 29: { // Generate Project Report
                int idx = selectEntity(pms.getProjects(), "Select a Project for Report:", [](const Project& p){ return p.getProjectName(); });
                if (idx != -1) pms.generateProjectReport(pms.getProjects()[idx].getProjectName());
                break;
            }

            // --- Exit ---
            case 30: { // Show Project Count
                cout << "\nTotal number of projects created: " << Project::getProjectCount() << endl;
                cout << "\nPress Enter to continue...";
                cin.get();
                break;
            }

            // --- Exit ---
            case 0: // Save and Exit
                pms.saveAllData();
                cout << "Exiting program. All data saved." << endl;
                break;

            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }
    } while (choice != 0);

    return 0;
}
