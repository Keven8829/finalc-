#ifndef PROJECT_H
#define PROJECT_H

#include <string>
#include <vector>
#include <iostream>

using namespace std;

class Project {
private:
    string projectName;
    string description;
    string startDate;
    string endDate;
    string status; // e.g., Not Started, In Progress, Completed

    // Associations
    vector<string> taskNames;
    vector<string> teamMemberNames;
    vector<string> vendorNames;
    vector<string> clientNames;

public:
    // Using 'inline' for C++17 standard for in-class definition. Source: cppreference.com - 'static storage class specifier'
    // Static member to count projects, defined inline
    static inline int projectCount = 0;

    // Static function to get the project count
    static int getProjectCount() {
        return projectCount;
    }

    // Default constructor
    Project() {
        projectCount++;
    }

    // Parameterized constructor
    Project(const string& name, const string& desc, const string& start, const string& end, const string& stat) {
        projectName = name;
        description = desc;
        startDate = start;
        endDate = end;
        status = stat;
        projectCount++;
    }
    
    // Copy constructor
    Project(const Project& other)
        : projectName(other.projectName), description(other.description),
          startDate(other.startDate), endDate(other.endDate), status(other.status),
          taskNames(other.taskNames), teamMemberNames(other.teamMemberNames),
          vendorNames(other.vendorNames), clientNames(other.clientNames)
    {
        projectCount++;
    }

    // Copy assignment operator
    Project& operator=(const Project& other) {
        if (this == &other) {
            return *this;
        }
        projectName = other.projectName;
        description = other.description;
        startDate = other.startDate;
        endDate = other.endDate;
        status = other.status;
        taskNames = other.taskNames;
        teamMemberNames = other.teamMemberNames;
        vendorNames = other.vendorNames;
        clientNames = other.clientNames;
        return *this;
    }

    // Destructor
    ~Project() {
        projectCount--;
    }

    // Method to update project details
    void updateDetails(const string& name, const string& desc, const string& start, const string& end, const string& stat) {
        projectName = name;
        description = desc;
        startDate = start;
        endDate = end;
        status = stat;
    }

    // Method to display project details
    void display(bool showAssociations) const {
        cout << "Project Name: " << projectName << endl;
        cout << "Description: " << description << endl;
        cout << "Start Date: " << startDate << endl;
        cout << "End Date: " << endDate << endl;
        cout << "Status: " << status << endl;

        if (showAssociations) {
            cout << "  Associated Tasks:" << endl;
            if (taskNames.empty()) {
                cout << "    (None)" << endl;
            } else {
                for(const auto& name : taskNames) {
                    cout << "    - " << name << endl;
                }
            }

            cout << "  Associated Team Members:" << endl;
            if (teamMemberNames.empty()) {
                cout << "    (None)" << endl;
            } else {
                for(const auto& name : teamMemberNames) {
                    cout << "    - " << name << endl;
                }
            }

            cout << "  Associated Vendors:" << endl;
            if (vendorNames.empty()) {
                cout << "    (None)" << endl;
            } else {
                for(const auto& name : vendorNames) {
                    cout << "    - " << name << endl;
                }
            }

            cout << "  Associated Clients:" << endl;
            if (clientNames.empty()) {
                cout << "    (None)" << endl;
            } else {
                for(const auto& name : clientNames) {
                    cout << "    - " << name << endl;
                }
            }
        }
    }

    // Methods to manage associations
    void assignTask(const string& taskName) {
        taskNames.push_back(taskName);
    }
    void assignTeamMember(const string& memberName) {
        teamMemberNames.push_back(memberName);
    }
    void assignVendor(const string& vendorName) {
        vendorNames.push_back(vendorName);
    }
    void assignClient(const string& clientName) {
        clientNames.push_back(clientName);
    }

    // Getters
    string getProjectName() const { return projectName; }
    string getDescription() const { return description; }
    string getStartDate() const { return startDate; }
    string getEndDate() const { return endDate; }
    string getStatus() const { return status; }

    // Setters for individual fields
    void setProjectName(const string& name) { projectName = name; }
    void setDescription(const string& desc) { description = desc; }
    void setStartDate(const string& start) { startDate = start; }
    void setEndDate(const string& end) { endDate = end; }
    void setStatus(const string& stat) { status = stat; }

    const vector<string>& getTaskNames() const { return taskNames; }
    const vector<string>& getTeamMemberNames() const { return teamMemberNames; }
    const vector<string>& getVendorNames() const { return vendorNames; }
    const vector<string>& getClientNames() const { return clientNames; }


};

#endif // PROJECT_H
