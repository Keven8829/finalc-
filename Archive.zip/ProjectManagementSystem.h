#ifndef PROJECTMANAGEMENTSYSTEM_H
#define PROJECTMANAGEMENTSYSTEM_H

#include "Project.h"
#include "Task.h"
#include "TeamMember.h"
#include "Vendor.h"
#include "Client.h"
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

class ProjectManagementSystem {
private:
    vector<Project> projects;
    vector<Task> tasks;
    vector<TeamMember> teamMembers;
    vector<Vendor> vendors;
    vector<Client> clients;

public:
    // Constructor and Destructor are no longer needed.
    // The compiler-generated defaults are sufficient.

    // --- Project Methods ---
    const vector<Project>& getProjects() const { return projects; }
    const vector<Task>& getTasks() const { return tasks; }
    const vector<TeamMember>& getTeamMembers() const { return teamMembers; }
    const vector<Vendor>& getVendors() const { return vendors; }
    const vector<Client>& getClients() const { return clients; }

    // Non-const getters for creating the allPeople list in main
    vector<TeamMember>& getTeamMembers_nonconst() { return teamMembers; }
    vector<Vendor>& getVendors_nonconst() { return vendors; }
    vector<Client>& getClients_nonconst() { return clients; }

    void addProject(const string& name, const string& desc, const string& start, const string& end, const string& stat) {
        projects.emplace_back(name, desc, start, end, stat);
    }



    void deleteProject(const string& name) {
        for (auto it = projects.begin(); it != projects.end(); ++it) {
            if (it->getProjectName() == name) {
                projects.erase(it);
                cout << "Project deleted successfully." << endl;
                return;
            }
        }
        cout << "Project not found!" << endl;
    }

    // --- Task Methods ---
    void addTask(const string& name, const string& desc, const string& start, const string& end, const string& stat) {
        tasks.emplace_back(name, desc, start, end, stat);
    }



    void updateTaskStatus(const string& taskName, const string& newStatus) {
        Task* task = findTask(taskName);
        if (task) {
            task->updateStatus(newStatus);
            cout << "Task status updated successfully." << endl;
        } else {
            cout << "Task not found!" << endl;
        }
    }

    void deleteTask(const string& name) {
        for (auto it = tasks.begin(); it != tasks.end(); ++it) {
            if (it->getTaskName() == name) {
                tasks.erase(it);
                cout << "Task deleted successfully." << endl;
                return;
            }
        }
        cout << "Task not found!" << endl;
    }

    void addSubTaskToTask(const string& parentTaskName, const Task& subTask) {
        Task* parentTask = findTask(parentTaskName);
        if (parentTask) {
            parentTask->addSubTask(subTask);
            cout << "Sub-task added successfully to '" << parentTaskName << "'." << endl;
        } else {
            cout << "Parent task not found!" << endl;
        }
    }

    void assignTaskToTeamMember(const string& taskName, const string& memberName) {
        Task* task = findTask(taskName);
        TeamMember* member = findTeamMember(memberName);

        if (task && member) {
            task->assignTeamMember(memberName);
            cout << "Task '" << taskName << "' assigned to team member '" << memberName << "'." << endl;
        } else {
            if (!task) cout << "Task not found!" << endl;
            if (!member) cout << "Team member not found!" << endl;
        }
    }

    void assignVendorToTask(const string& taskName, const string& vendorName) {
        Task* task = findTask(taskName);
        Vendor* vendor = findVendor(vendorName);

        if (task && vendor) {
            task->assignVendor(vendorName);
            cout << "Task '" << taskName << "' assigned to vendor '" << vendorName << "'." << endl;
        } else {
            if (!task) cout << "Task not found!" << endl;
            if (!vendor) cout << "Vendor not found!" << endl;
        }
    }

    // --- TeamMember Methods ---
    void addTeamMember(const string& name, const string& role, const string& contact) {
        teamMembers.emplace_back(name, role, contact);
    }



    void deleteTeamMember(const string& name) {
        for (auto it = teamMembers.begin(); it != teamMembers.end(); ++it) {
            if (it->getName() == name) {
                teamMembers.erase(it);
                cout << "Team member deleted successfully." << endl;
                return;
            }
        }
        cout << "Team member not found!" << endl;
    }

    // --- Vendor Methods ---
    void addVendor(const string& name, const string& type, const string& contact) {
        vendors.emplace_back(name, type, contact);
    }



    void deleteVendor(const string& name) {
        for (auto it = vendors.begin(); it != vendors.end(); ++it) {
            if (it->getName() == name) {
                vendors.erase(it);
                cout << "Vendor deleted successfully." << endl;
                return;
            }
        }
        cout << "Vendor not found!" << endl;
    }

    // --- Client Methods ---
    void addClient(const string& name, const string& type, const string& contact) {
        clients.emplace_back(name, type, contact);
    }



    void deleteClient(const string& name) {
        for (auto it = clients.begin(); it != clients.end(); ++it) {
            if (it->getName() == name) {
                clients.erase(it);
                cout << "Client deleted successfully." << endl;
                return;
            }
        }
        cout << "Client not found!" << endl;
    }

    // --- Association Methods ---
    void assignTaskToProject(const string& projectName, const string& taskName) {
        Project* project = findProject(projectName);
        Task* task = findTask(taskName);

        if (project && task) {
            project->assignTask(taskName);
            cout << "Task '" << taskName << "' assigned to project '" << projectName << "'." << endl;
        } else {
            if (!project) cout << "Project not found!" << endl;
            if (!task) cout << "Task not found!" << endl;
        }
    }

    void assignTeamMemberToProject(const string& projectName, const string& memberName) {
        Project* project = findProject(projectName);
        TeamMember* member = findTeamMember(memberName);

        if (project && member) {
            project->assignTeamMember(memberName);
            cout << "Team Member '" << memberName << "' assigned to project '" << projectName << "'." << endl;
        } else {
            if (!project) cout << "Project not found!" << endl;
            if (!member) cout << "Team Member not found!" << endl;
        }
    }

    void assignVendorToProject(const string& projectName, const string& vendorName) {
        Project* project = findProject(projectName);
        Vendor* vendor = findVendor(vendorName);

        if (project && vendor) {
            project->assignVendor(vendorName);
            cout << "Vendor '" << vendorName << "' assigned to project '" << projectName << "'." << endl;
        } else {
            if (!project) cout << "Project not found!" << endl;
            if (!vendor) cout << "Vendor not found!" << endl;
        }
    }

    void assignClientToProject(const string& projectName, const string& clientName) {
        Project* project = findProject(projectName);
        Client* client = findClient(clientName);

        if (project && client) {
            project->assignClient(clientName);
            cout << "Client '" << clientName << "' assigned to project '" << projectName << "'." << endl;
        } else {
            if (!project) cout << "Project not found!" << endl;
            if (!client) cout << "Client not found!" << endl;
        }
    }

    // --- Display Methods ---
    void displayAllProjects() const {
        cout << "--- Projects ---" << endl;
        for (const auto& p : projects) {
            p.display(true); // Show associations
            cout << endl;
        }
    }

    void displayAllTasks() const {
        cout << "--- Tasks ---" << endl;
        for (const auto& t : tasks) {
            t.display();
            cout << endl;
        }
    }

    void displayAllTeamMembers() const {
        cout << "--- Team Members ---" << endl;
        for (const auto& tm : teamMembers) {
            tm.display();
            cout << endl;
        }
    }

    void displayAllVendors() const {
        cout << "--- Vendors ---" << endl;
        for (const auto& v : vendors) {
            v.display();
            cout << endl;
        }
    }

    void displayAllClients() const {
        cout << "--- Clients ---" << endl;
        for (const auto& c : clients) {
            c.display();
            cout << endl;
        }
    }

    // --- Specific Display Methods ---
    void displayProjectDetails(const string& name) const {
        for (const auto& p : projects) {
            if (p.getProjectName() == name) {
                p.display(true); // Show associations
                return;
            }
        }
        cout << "Project not found!" << endl;
    }

    void displayTaskDetails(const string& name) const {
        const Task* task = findTaskRecursive(tasks, name);
        if (task) {
            task->display();
        } else {
            cout << "Task not found!" << endl;
        }
    }

    void displayTeamMemberDetails(const string& name) const {
        for (const auto& tm : teamMembers) {
            if (tm.getName() == name) {
                tm.display();
                return;
            }
        }
        cout << "Team member not found!" << endl;
    }



    void findPersonAndShowProjects(const string& personName) const {
        // This method is not const because find methods return non-const pointers to allow modification.
        // A const version could be made if only display was needed.
        const Person* person = nullptr;

        // Search for the person across all types
        if (const auto* p = findTeamMember(personName)) person = p;
        else if (const auto* p = findVendor(personName)) person = p;

        if (!person) {
            cout << "Person '" << personName << "' not found in the system." << endl;
            return;
        }

        cout << "\n--- Involvement Report for '" << personName << "' ---" << endl;
        cout << "-----------------------------------------" << endl;

        // Display Person's Details (Polymorphism)
        cout << "\n--- Person Details ---" << endl;
        person->display();

        // Find and Display Project Involvement
        cout << "\n--- Project Assignments ---" << endl;
        vector<string> involvedProjects;
        for (const auto& project : projects) {
            bool isAssigned = false;
            // Check if the person is in any of the project's assignment lists
            for(const auto& name : project.getTeamMemberNames()) if(name == personName) isAssigned = true;
            for(const auto& name : project.getVendorNames()) if(name == personName) isAssigned = true;

            if (isAssigned) {
                involvedProjects.push_back(project.getProjectName());
            }
        }

        if (involvedProjects.empty()) {
            cout << "  (None)" << endl;
        } else {
            for (const auto& projName : involvedProjects) {
                cout << "  - " << projName << endl;
            }
        }

        // Find and Display Task Involvement
        cout << "\n--- Task Assignments ---" << endl;
        vector<const Task*> involvedTasks;
        for (const auto& task : tasks) {
            // Check if the person is assigned to the task
            if (task.getAssignedTo() == personName || task.getAssignedVendor() == personName) {
                involvedTasks.push_back(&task);
            }
        }

        if (involvedTasks.empty()) {
            cout << "  (None)" << endl;
        } else {
            for (const auto* taskPtr : involvedTasks) {
                cout << "  - " << taskPtr->getTaskName() << " (" << taskPtr->getStatus() << ")" << endl;
            }
        }
        cout << "-----------------------------------------" << endl;
        cout << "--- End of Report ---" << endl;
    }

    void generateProjectReport(const string& projectName) const {
        // This method is not const because find methods return non-const pointers to allow modification.
        // A const version could be made if only display was needed.
        const Project* project = findProject(projectName);
        if (!project) {
            cout << "Project not found!" << endl;
            return;
        }

        cout << "\n--- Project Report for '" << projectName << "' ---" << endl;
        cout << "-----------------------------------------" << endl;

        // Display Project Details
        project->display(false); // false to not show associated entity names

        // Display Associated Tasks
        cout << "\n--- Tasks ---" << endl;
        if (project->getTaskNames().empty()) {
            cout << "No tasks assigned to this project." << endl;
        } else {
            for (const auto& taskName : project->getTaskNames()) {
                const Task* task = findTask(taskName);
                if (task) { // Check if the task was found to prevent crash
                    task->display();
                } else {
                    cout << "  - [Error] Task '" << taskName << "' is assigned to project but not found in system." << endl;
                }
            }
        }

        // Display Associated People (Polymorphism in action)
        cout << "\n--- Associated People ---" << endl;
        vector<const Person*> associatedPeople;

        // Gather Team Members
        for (const auto& memberName : project->getTeamMemberNames()) {
            const TeamMember* member = findTeamMember(memberName);
            if (member) {
                associatedPeople.push_back(member);
            }
        }

        // Gather Vendors
        for (const auto& vendorName : project->getVendorNames()) {
            const Vendor* vendor = findVendor(vendorName);
            if (vendor) {
                associatedPeople.push_back(vendor);
            }
        }

        // Gather Clients
        for (const auto& clientName : project->getClientNames()) {
            const Client* client = findClient(clientName);
            if (client) {
                associatedPeople.push_back(client);
            }
        }

        if (associatedPeople.empty()) {
            cout << "No people assigned to this project." << endl;
        } else {
            for (const Person* person : associatedPeople) {
                person->display(); // Virtual function call
                cout << endl;
            }
        }
        cout << "-----------------------------------------" << endl;
        cout << "--- End of Report ---" << endl;
    }

    void displayAllDetails() const {
        displayAllProjects();
        displayAllTasks();
        displayAllTeamMembers();
        displayAllVendors();
        displayAllClients();
    }

    // --- Data Persistence Methods ---
    void loadAllData() {
        loadProjects();
        loadTasks();
        loadTeamMembers();
        loadVendors();
        loadClients();
        cout << "All data loaded successfully." << endl;
    }

    void saveAllData() {
        saveProjects();
        saveTasks();
        saveTeamMembers();
        saveVendors();
        saveClients();
        cout << "All data saved successfully." << endl;
    }

private:
    // File I/O using std::ifstream for reading CSV. Source: C++ Primer, Chapter on I/O Library.
    // --- Private Helper Methods for Data Persistence ---
    void loadProjects() {
        ifstream file("projects.csv");
        if (!file.is_open()) return;
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string name, desc, start, end, stat, tasksStr, membersStr, vendorsStr, clientsStr;
            getline(ss, name, ',');
            getline(ss, desc, ',');
            getline(ss, start, ',');
            getline(ss, end, ',');
            getline(ss, stat, ',');
            getline(ss, tasksStr, ',');
            getline(ss, membersStr, ',');
            getline(ss, vendorsStr, ',');
            getline(ss, clientsStr, ',');

            Project p(name, desc, start, end, stat);

            stringstream tasksSS(tasksStr);
            string taskName;
            while(getline(tasksSS, taskName, ';')) {
                if (!taskName.empty()) p.assignTask(taskName);
            }

            stringstream membersSS(membersStr);
            string memberName;
            while(getline(membersSS, memberName, ';')) {
                if (!memberName.empty()) p.assignTeamMember(memberName);
            }

            stringstream vendorsSS(vendorsStr);
            string vendorName;
            while(getline(vendorsSS, vendorName, ';')) {
                if (!vendorName.empty()) p.assignVendor(vendorName);
            }

            stringstream clientsSS(clientsStr);
            string clientName;
            while(getline(clientsSS, clientName, ';')) {
                if (!clientName.empty()) p.assignClient(clientName);
            }

            projects.push_back(p);
        }
        file.close();
    }

    void saveProjects() {
        ofstream file("projects.csv");
        for (const auto& p : projects) {
            file << p.getProjectName() << ',' << p.getDescription() << ',' << p.getStartDate() << ',' << p.getEndDate() << ',' << p.getStatus() << ',';

            for (size_t i = 0; i < p.getTaskNames().size(); ++i) {
                file << p.getTaskNames()[i] << (i < p.getTaskNames().size() - 1 ? ";" : "");
            }
            file << ',';

            for (size_t i = 0; i < p.getTeamMemberNames().size(); ++i) {
                file << p.getTeamMemberNames()[i] << (i < p.getTeamMemberNames().size() - 1 ? ";" : "");
            }
            file << ',';

            for (size_t i = 0; i < p.getVendorNames().size(); ++i) {
                file << p.getVendorNames()[i] << (i < p.getVendorNames().size() - 1 ? ";" : "");
            }
            file << ',';

            for (size_t i = 0; i < p.getClientNames().size(); ++i) {
                file << p.getClientNames()[i] << (i < p.getClientNames().size() - 1 ? ";" : "");
            }
            file << endl;
        }
        file.close();
    }

    void loadTasks() {
        ifstream file("tasks.csv");
        if (!file.is_open()) return;
        vector<pair<Task, int>> loadedTasks;
        string line;

        while (getline(file, line)) {
            int depth = 0;
            while (depth < line.length() && line[depth] == '\t') {
                depth++;
            }
            line = line.substr(depth);

            stringstream ss(line);
            string name, desc, start, end, stat, assigned, vendor;
            getline(ss, name, ',');
            getline(ss, desc, ',');
            getline(ss, start, ',');
            getline(ss, end, ',');
            getline(ss, stat, ',');
            getline(ss, assigned, ',');
            getline(ss, vendor, ',');
            loadedTasks.emplace_back(Task(name, desc, start, end, stat, assigned, vendor), depth);
        }
        file.close();

        tasks.clear();
        vector<Task*> parentStack;
        if (!tasks.empty()) {
            parentStack.push_back(&tasks.back());
        }
        for (auto& task_pair : loadedTasks) {
            if (task_pair.second == 0) {
                tasks.push_back(task_pair.first);
                parentStack.assign(1, &tasks.back());
            } else {
                while (parentStack.size() > task_pair.second) {
                    parentStack.pop_back();
                }
                if (!parentStack.empty()) {
                    Task* parent = parentStack.back();
                    parent->addSubTask(task_pair.first);
                    parentStack.push_back(&parent->getSubTasks_nonconst().back());
                }
            }
        }
    }

    void saveTasks() {
        ofstream file("tasks.csv");
        for (const auto& t : tasks) {
            saveTaskRecursive(file, t, 0);
        }
        file.close();
    }

    void loadTeamMembers() {
        ifstream file("teammembers.csv");
        if (!file.is_open()) return;
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string name, role, contact;
            getline(ss, name, ',');
            getline(ss, role, ',');
            getline(ss, contact, ',');
            teamMembers.emplace_back(name, role, contact);
        }
        file.close();
    }

    void saveTeamMembers() {
        ofstream file("teammembers.csv");
        for (const auto& tm : teamMembers) {
            file << tm.getName() << ',' << tm.getRole() << ',' << tm.getContactInfo() << endl;
        }
        file.close();
    }

    void loadVendors() {
        ifstream file("vendors.csv");
        if (!file.is_open()) return;
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string name, type, contact;
            getline(ss, name, ',');
            getline(ss, type, ',');
            getline(ss, contact, ',');
            vendors.emplace_back(name, type, contact);
        }
        file.close();
    }

    void saveVendors() {
        ofstream file("vendors.csv");
        for (const auto& v : vendors) {
            file << v.getName() << ',' << v.getCompanyType() << ',' << v.getContactInfo() << endl;
        }
        file.close();
    }

    void loadClients() {
        ifstream file("clients.csv");
        if (!file.is_open()) return;
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string name, type, contact;
            getline(ss, name, ',');
            getline(ss, type, ',');
            getline(ss, contact, ',');
            clients.emplace_back(name, type, contact);
        }
        file.close();
    }

    void saveClients() {
        ofstream file("clients.csv");
        for (const auto& c : clients) {
            file << c.getName() << ',' << c.getIndustryType() << ',' << c.getContactInfo() << endl;
        }
        file.close();
    }

public:
    // --- Public Helper Methods for finding entities ---
    Project* findProject(const string& name) { 
        for (auto& p : projects) {
            if (p.getProjectName() == name) return &p;
        }
        return nullptr;
    }
    const Project* findProject(const string& name) const { 
        for (const auto& p : projects) {
            if (p.getProjectName() == name) return &p;
        }
        return nullptr;
    }
    Task* findTask(const string& name) { 
        for (auto& t : tasks) {
            if (t.getTaskName() == name) return &t;
            // TODO: Implement recursive search for sub-tasks
        }
        return nullptr;
    }
    const Task* findTask(const string& name) const { 
        for (const auto& t : tasks) {
            if (t.getTaskName() == name) return &t;
            // TODO: Implement recursive search for sub-tasks
        }
        return nullptr;
    }

    TeamMember* findTeamMember(const string& name) { 
        for (auto& tm : teamMembers) {
            if (tm.getName() == name) return &tm;
        }
        return nullptr;
    }
    const TeamMember* findTeamMember(const string& name) const { 
        for (const auto& tm : teamMembers) {
            if (tm.getName() == name) return &tm;
        }
        return nullptr;
    }

    Vendor* findVendor(const string& name) { 
        for (auto& v : vendors) {
            if (v.getName() == name) return &v;
        }
        return nullptr;
    }
    const Vendor* findVendor(const string& name) const { 
        for (const auto& v : vendors) {
            if (v.getName() == name) return &v;
        }
        return nullptr;
    }

    Client* findClient(const string& name) { 
        for (auto& c : clients) {
            if (c.getName() == name) return &c;
        }
        return nullptr;
    }
    const Client* findClient(const string& name) const { 
        for (const auto& c : clients) {
            if (c.getName() == name) return &c;
        }
        return nullptr;
    }


private:
    const Task* findTaskRecursive(const vector<Task>& taskList, const string& name) const {
        for (const auto& task : taskList) {
            if (task.getTaskName() == name) {
                return &task;
            }
            const Task* found = findTaskRecursive(task.getSubTasks(), name);
            if (found) {
                return found;
            }
        }
        return nullptr;
    }

    void saveTaskRecursive(ofstream& file, const Task& task, int depth) {
        for (int i = 0; i < depth; ++i) {
            file << "\t";
        }
        file << task.getTaskName() << ',' << task.getDescription() << ',' << task.getStartDate() << ',' << task.getEndDate() << ',' << task.getStatus() << ',' << task.getAssignedTo() << ',' << task.getAssignedVendor() << endl;
        for (const auto& subTask : task.getSubTasks()) {
            saveTaskRecursive(file, subTask, depth + 1);
        }
    }
};

#endif // PROJECTMANAGEMENTSYSTEM_H
