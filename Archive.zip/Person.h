#ifndef PERSON_H
#define PERSON_H

#include <string>
#include <iostream>

using namespace std;

// Base class for any entity that represents a person or contact
class Person {
protected:
    string name;
    string contactInfo;

public:
    // Default constructor
    Person() = default;

    // Parameterized constructor
    Person(const string& pName, const string& pContact) {
        name = pName;
        contactInfo = pContact;
    }

    // Virtual destructor for polymorphism
    virtual ~Person() {}

    // Virtual function for displaying details
    virtual void display() const {
        cout << "Name: " << name << endl;
    }

    // Getters
    string getName() const { return name; }
    string getContactInfo() const { return contactInfo; }

    // Setters
    void setName(const string& newName) { name = newName; }
    void setContactInfo(const string& newContact) { contactInfo = newContact; }


};

#endif // PERSON_H
