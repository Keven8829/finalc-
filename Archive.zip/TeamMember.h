#ifndef TEAMMEMBER_H
#define TEAMMEMBER_H

#include "Person.h"

class TeamMember : public Person {
private:
    string role;

public:
    // Default constructor
    TeamMember() = default;

    // Parameterized constructor
    TeamMember(const string& name, const string& role, const string& contact)
        : Person(name, contact) {
        this->role = role;
    }



    // Overridden method to display team member details
    void display() const override {
        cout << "Name: " << getName() << endl;
        cout << "Role: " << role << endl;
        cout << "Contact Info: " << getContactInfo() << endl;
    }

    // Getter for role
    string getRole() const {
        return role;
    }

    void setRole(const string& newRole) {
        role = newRole;
    }
};

#endif // TEAMMEMBER_H
