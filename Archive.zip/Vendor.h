#ifndef VENDOR_H
#define VENDOR_H

#include "Person.h"

class Vendor : public Person {
private:
    string companyType;

public:
    // Default constructor
    Vendor() = default;

    // Parameterized constructor
    Vendor(const string& name, const string& type, const string& contact)
        : Person(name, contact) {
        companyType = type;
    }



    // Overridden method to display vendor details
    void display() const override {
        cout << "Company Name: " << getName() << endl;
        cout << "Company Type: " << companyType << endl;
        cout << "Contact Person: " << getContactInfo() << endl;
    }

    // Getter for company type
    string getCompanyType() const {
        return companyType;
    }

    void setCompanyType(const string& newType) {
        companyType = newType;
    }
};

#endif // VENDOR_H
